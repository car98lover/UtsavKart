import React from "react";
import { Typography, Step, StepLabel, Stepper } from "@mui/material";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import LibraryAddCheckIcon from "@mui/icons-material/LibraryAddCheck";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import { Link, useLocation } from "react-router-dom";
import "./CheckoutSteps.css";

const CheckoutSteps = () => {
  const steps = [
    {
      label: <Typography>Shipping Details</Typography>,
      icon: <LocalShippingIcon />,
      link: "shipping",
    },
    {
      label: <Typography>Confirm Order</Typography>,
      icon: <LibraryAddCheckIcon />,
      link: "confirm",
    },
    {
      label: <Typography>Payment</Typography>,
      icon: <AccountBalanceIcon />,
      link: "payment",
    },
  ];

  const location = useLocation();

  return (
    <Stepper activeStep={steps.findIndex((step) => location.pathname.includes(step.link))} alternativeLabel>
      {steps.map((step, index) => (
        <Step key={index} completed={false}>
          <StepLabel>
            <Link
              to={`/${step.link}`}
              style={{
                textDecoration: "none",
                color: location.pathname.includes(step.link) ? "tomato" : "rgba(0, 0, 0, 0.649)",
              }}
            >
              {step.icon}
              {step.label}
            </Link>
          </StepLabel>
        </Step>
      ))}
    </Stepper>
  );
};

export default CheckoutSteps;
